Kitakyushu Central Library – HTML-Übersicht

1. Das ZIP vollständig entpacken.
2. index.html im Browser öffnen (z. B. Firefox, Chrome oder Edge).
3. Der Ordner bilder muss neben index.html bleiben.

Alle Fotos und Pläne liegen im Paket. Keine Internetverbindung für die Bildanzeige erforderlich. Quellenlinks öffnen die Originalquellen im Internet.
